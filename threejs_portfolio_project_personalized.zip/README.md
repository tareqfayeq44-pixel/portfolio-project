
Three.js Desert Scene — Lightweight Portfolio Project
----------------------------------------------------

What's inside:
- index.html : the web page (references Three.js via CDN)
- script.js  : the scene code (small procedurally-generated models)
- style.css  : minimal styling
- scholarship_portfolio_for_download.pdf : sample PDF (links to this file from the overlay)

How to use:
1. Unzip the folder and open index.html in a browser (desktop or mobile).
   - For best mobile experience open the page in Chrome or Firefox mobile.
2. To host online:
   - GitHub Pages: create a repo, upload the files, enable Pages from branch 'main' -> / (root).
   - Netlify: drag-and-drop the folder into Netlify Drop (free) and you'll get a public URL.
   - Vercel: import the repo and deploy (static site).
3. To embed in your portfolio site, use an iframe:
   <iframe src="https://your-site.example/threejs_project/index.html" width="100%" height="600"></iframe>

Size:
- The project is very small because models are procedural. The zip (without PNG/JPEG) should be < 1 MB (excluding the PDF).
- If you add screenshots or video, the size grows depending on those files.

Want me to:
- Fill the scene with your name/logo and change colors?
- Create a GitHub repo and deploy it to GitHub Pages for you (I can provide exact steps and the files)?
- Convert this to a Spline scene instead?
