
// Lightweight Three.js desert-like scene.
// Works on desktop and mobile. Small models (procedural) so size is tiny.

let scene, camera, renderer, controls;
init();
animate();

function init() {
  const container = document.getElementById('container');
  scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0xd7c9a3, 0.0025);

  const w = window.innerWidth, h = window.innerHeight;
  camera = new THREE.PerspectiveCamera(45, w/h, 0.1, 1000);
  camera.position.set(0, 6, 12);

  renderer = new THREE.WebGLRenderer({antialias:true});
  renderer.setSize(w,h);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0xece0b8);
  container.appendChild(renderer.domElement);

  // Light
  const hemi = new THREE.HemisphereLight(0xfff7e6, 0x8888ff, 0.9);
  scene.add(hemi);
  const dir = new THREE.DirectionalLight(0xfff1c7, 0.8);
  dir.position.set(5,10,2);
  scene.add(dir);

  // Ground (simple plane with waves)
  const geom = new THREE.PlaneGeometry(200,200,80,80);
  geom.rotateX(-Math.PI/2);
  for (let i=0;i<geom.attributes.position.count;i++){
    const y = Math.sin(i*0.12)*0.08 + (Math.random()-0.5)*0.02;
    geom.attributes.position.setY(i, y);
  }
  geom.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({color:0xe6cf9b, roughness:1});
  const ground = new THREE.Mesh(geom, mat);
  scene.add(ground);

  // Simple rocks / dunes (instances)
  const rockGeom = new THREE.SphereGeometry(1,12,10);
  for (let i=0;i<30;i++){
    const m = new THREE.Mesh(rockGeom, mat.clone());
    const s = 0.3 + Math.random()*1.2;
    m.scale.set(s, s*0.6, s);
    m.position.set((Math.random()-0.5)*40, 0.2, (Math.random()-0.5)*40);
    m.rotation.y = Math.random()*Math.PI;
    m.castShadow = true;
    scene.add(m);
  }

  // A simple monument / arch as focal point
  const arch = new THREE.Group();
  const box = new THREE.BoxGeometry(1.2,3,0.6);
  const boxMat = new THREE.MeshStandardMaterial({color:0xcd8f5a});
  const left = new THREE.Mesh(box, boxMat); left.position.set(-1.1,1.5,0);
  const right = new THREE.Mesh(box, boxMat); right.position.set(1.1,1.5,0);
  const top = new THREE.Mesh(new THREE.BoxGeometry(2.6,0.4,0.8), boxMat); top.position.set(0,3.05,0);
  const hole = new THREE.Mesh(new THREE.BoxGeometry(1.0,1.6,0.4));
  hole.position.set(0,1.15,0);
  arch.add(left,right,top);
  arch.position.set(0,0, -6);
  scene.add(arch);

  // Sky gradient using large sphere
  const skyGeo = new THREE.SphereGeometry(300, 32, 15);
  const skyMat = new THREE.MeshBasicMaterial({color:0xe7d9b3, side: THREE.BackSide});
  const sky = new THREE.Mesh(skyGeo, skyMat);
  scene.add(sky);

  // Controls
  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.07;
  controls.minDistance = 4;
  controls.maxDistance = 50;
  controls.maxPolarAngle = Math.PI/2 - 0.05;

  window.addEventListener('resize', onWindowResize);
  // touch-friendly: allow pinch zoom handled by controls
}

function onWindowResize(){
  const w = window.innerWidth, h = window.innerHeight;
  camera.aspect = w/h;
  camera.updateProjectionMatrix();
  renderer.setSize(w,h);
}

function animate(){
  requestAnimationFrame(animate);
  // subtle time-based movement
  const t = performance.now()*0.0002;
  scene.rotation.y = Math.sin(t)*0.002;
  controls.update();
  renderer.render(scene, camera);
}
